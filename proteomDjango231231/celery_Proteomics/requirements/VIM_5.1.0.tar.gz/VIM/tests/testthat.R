library(testthat)
library(VIM)
test_check("VIM")
